﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Imobiliaria_Seu_Lobato
{
    class Program
    {
        //DATA
        public struct Data
        {
            public string dia, mes, ano;
        }

        //PROPRIETÁRIO
        public struct Proprietario
        {
            public int codigo;
            public string nome, endereço, telefone;
        }

        //CLIENTE
        public struct Cliente
        {
            public int codigo;
            public string nome, endereço, telefone;
            public Data nascimento;
        }

        //CORRETOR
        public struct Corretor
        {
            public int codigo;
            public string nome, telefone;
            public double salario;
        }

        //IMOVEL
        public struct Imovel
        {
            public int codigo;
            public string endereco, categoria, tipo, status, observacoes, codigoprop, qtdequarto, qtdevagas;
            public double valor, condominio;
        }

        //LOCAÇÕES
        public struct Locacoes
        {
            public int numloc, codigoimv, codigoci;
            public double valoralu, taxaadm, valortot;
            public Data inicioloc, duracaoloc;
        }

        //VENDAS
        public struct Vendas
        {
            public int numvenda, codigoim, codigoci, codigocorret;
            public double valorvenda, taxaadm, valortotal;
            public Data datavenda;
        }

        //gerar venda
        public static void GeraAlguel()
        {
            Console.Clear();
            Console.WriteLine("Cadastrar Aluguel: ");

            string linha;
            FileStream arq = new FileStream("aluguel.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            //gerar codigo
            string[] resultado;
            //armazenar no cod o ultimo codigo registrado
            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                }
            } while (linha != null);

            ler.Close();



        }

        //validar codigo proprietario
        public static bool Valida_CodProprietario(string cod)
        {
            string linha;
            bool valida = false;

            FileStream arq = new FileStream("proprietario.txt", FileMode.Open);
            StreamReader ler = new StreamReader(arq);


            string[] resultado;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split(',');
                    //se o codigo digitado existir
                    if (cod == resultado[0])
                    {
                        valida = true;
                        break;
                    }
                }
            } while (linha != null);

            ler.Close();

            return valida;
        }

        //CADASTRAR IMOVEIS
        public static void CadastraImovel()
        {
            Console.Clear();
            string linha, cod = "0", cod_proprietario;
            int codigo;
            Imovel Imovel = new Imovel();

            Console.WriteLine("Imobiliária Seu Lobato: Cadastro de Imovel: ");

            FileStream arq = new FileStream("imovel.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            //gerar codigo
            string[] resultado;
            //armazenar no cod o ultimo codigo registrado
            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    cod = resultado[0];
                }
            } while (linha != null);

            ler.Close();

            //passou de string para int
            codigo = int.Parse(cod);
            //adicionou mais 1
            codigo++;

            Imovel.codigo = codigo;

            //valida cod proprietario
            do
            {
                Console.WriteLine("Digite o Código do Proprietario: ");
                cod_proprietario = Console.ReadLine();

                if (Valida_CodProprietario(cod_proprietario) == false)
                {
                    Console.WriteLine("Código de proprietario não registrado!");
                }

            } while (Valida_CodProprietario(cod_proprietario) == false);

            Imovel.codigoprop = cod_proprietario;

            Console.WriteLine("Digite o endereço do Imóvel:");
            Imovel.endereco = Console.ReadLine();

            Console.WriteLine("Digite a categoria (casa/apartamento/etc..):");
            Imovel.categoria = Console.ReadLine();

            //valida aluguel ou venda
            string opc;
            do
            {
                Console.WriteLine("Escolha o tipo do imovel ");
                Console.WriteLine("1- Venda");
                Console.WriteLine("2- Aluguel");
                Console.Write("Opção: ");
                opc = Console.ReadLine();

                if (opc != "1" && opc != "2")
                {
                    Console.WriteLine("Opção Invalida! Digite Novamente");
                }

            } while (opc != "1" && opc != "2");

            if (opc == "1")
            {
                Imovel.tipo = "Venda";
            }
            else
            {
                Imovel.tipo = "Aluguel";
            }

            Console.WriteLine("Digite a quantidade de vagas do Imóvel:");
            Imovel.qtdevagas = Console.ReadLine();

            Console.WriteLine("Digite a quantidade de quartos do Imóvel:");
            Imovel.qtdequarto = Console.ReadLine();

            Console.WriteLine("Digite o valor do(a) " + Imovel.tipo + ": ");
            Imovel.valor = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do Condominio: ");
            Imovel.condominio = double.Parse(Console.ReadLine());

            if (Imovel.tipo == "Aluguel")
            {
                Imovel.status = "a alugar";
            }
            else
            {
                Imovel.status = "a vender";
            }

            Console.WriteLine("Observações: ");
            Imovel.observacoes = Console.ReadLine();

            FileStream arq1 = new FileStream("imovel.txt", FileMode.Append);
            StreamWriter escreve = new StreamWriter(arq1);

            escreve.Write(Imovel.codigo);
            escreve.Write("|" + Imovel.codigoprop);
            escreve.Write("|" + Imovel.endereco);
            escreve.Write("|" + Imovel.categoria);
            escreve.Write("|" + Imovel.tipo);
            escreve.Write("|" + Imovel.qtdequarto);
            escreve.Write("|" + Imovel.qtdevagas);
            escreve.Write("|" + Imovel.valor);
            escreve.Write("|" + Imovel.condominio);
            escreve.Write("|" + Imovel.status);
            escreve.Write("|" + Imovel.observacoes);
            //pula pra proxima linha
            escreve.WriteLine("");

            escreve.Close();
        }

        //CADASTRO DO CORRETOR
        public static void CadastraCorretor()
        {
            Console.Clear();
            string linha, cod = "0";
            int codigo;
            Corretor corretor = new Corretor();

            Console.WriteLine(" Imobiliária Seu Lobato: Cadastro de Corretores: ");

            FileStream arq = new FileStream("corretor.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            //gerar codigo
            string[] resultado;
            //armazenar no cod o ultimo codigo registrado
            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    cod = resultado[0];
                }
            } while (linha != null);

            ler.Close();

            
            //passou de string para int
            int.TryParse(cod, out codigo);
            //adicionou mais 1
            codigo = codigo + 1;

            corretor.codigo = codigo;
            Console.WriteLine("Digite o nome do corretor:");
            corretor.nome = Console.ReadLine();
            Console.WriteLine("Digite o telefone do corretor:");
            corretor.telefone = Console.ReadLine();
            Console.WriteLine("Digite o seu salario: ");
            corretor.salario = double.Parse(Console.ReadLine());

            FileStream arq1 = new FileStream("corretor.txt", FileMode.Append);
            StreamWriter escreve = new StreamWriter(arq);

            escreve.Write(corretor.codigo);
            escreve.Write("|" + corretor.nome);
            escreve.Write("|" + corretor.telefone);
            escreve.Write("|" + corretor.salario);
            //pula pra proxima linha
            escreve.WriteLine("");

            escreve.Close();
        }

        //CADASTRO DE CLIENTE
        public static void CadastraCliente()
        {
            Console.Clear();
            string linha, cod = "0", dataNasc;
            int codigo;
            Cliente client = new Cliente();

            Console.WriteLine(" Imobiliária Seu Lobato: Cadastro de cliente: ");

            FileStream arq = new FileStream("cliente.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            //gerar codigo
            string[] resultado;
            //armazenar no cod o ultimo codigo registrado
            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    cod = resultado[0];
                }
            } while (linha != null);

            ler.Close();

            //passou de string para int
            int.TryParse(cod, out codigo);
            //adicionou mais 1
            codigo = codigo + 1;

            client.codigo = codigo;
            Console.WriteLine("Digite o nome do cliente:");
            client.nome = Console.ReadLine();
            Console.WriteLine("Digite o endereço do cliente:");
            client.endereço = Console.ReadLine();
            Console.WriteLine("Digite o telefone do cliente:");
            client.telefone = Console.ReadLine();
            Console.WriteLine("Digite a Data de Nascimento nesse formato com as barras DD/MM/AAAA:");
            dataNasc = Console.ReadLine();

            //separar data
            string[] data;
            data = dataNasc.Split('/');

            client.nascimento.dia = data[0];
            client.nascimento.mes = data[1];
            client.nascimento.ano = data[2];

            FileStream arq1 = new FileStream("cliente.txt", FileMode.Append);
            StreamWriter escreve = new StreamWriter(arq1);

            escreve.Write(client.codigo);
            escreve.Write("|" + client.nome);
            escreve.Write("|" + client.endereço);
            escreve.Write("|" + client.telefone);
            escreve.Write("|" + client.nascimento.dia);
            escreve.Write("|" + client.nascimento.mes);
            escreve.Write("|" + client.nascimento.ano);
            //pula pra proxima linha
            escreve.WriteLine("");

            escreve.Close();
        }

        //CADASTRO DE PROPRIETÁRIO
        public static void CadastraProp()
        {
            Console.Clear();
            string linha, cod = "0";
            int codigo;
            Proprietario prop = new Proprietario();

            Console.WriteLine(" Imobiliária Seu Lobato: Cadastro de proprietário: ");

            FileStream arq = new FileStream("proprietario.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            //gerar codigo
            string[] resultado;
            //armazenar no cod o ultimo codigo registrado
            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    cod = resultado[0];
                }
            } while (linha != null);

            ler.Close();

            //passou de string para int
            int.TryParse(cod, out codigo);
            //adicionou mais 1
            codigo = codigo + 1;


            prop.codigo = codigo;
            Console.WriteLine("Digite o nome do proprietário:");
            prop.nome = Console.ReadLine();
            Console.WriteLine("Digite o endereço do proprietário:");
            prop.endereço = Console.ReadLine();
            Console.WriteLine("Digite o telefone do proprietário:");
            prop.telefone = Console.ReadLine();

            FileStream arq1 = new FileStream("proprietario.txt", FileMode.Append);
            StreamWriter escreve = new StreamWriter(arq1);


            escreve.Write(prop.codigo);
            escreve.Write("|" + prop.nome);
            escreve.Write("|" + prop.endereço);
            escreve.Write("|" + prop.telefone);
            //pula pra proxima linha
            escreve.WriteLine("");

            escreve.Close();
        }

        public static void Menu()
        {
            string opc = "", opc_secundaria = "";
            do
            {
                Console.Clear();
                Console.WriteLine("--------------------------");
                Console.WriteLine("| Imobiliária Seu Lobato |");
                Console.WriteLine("--------------------------");
                Console.WriteLine("|1- Cadastrar            |");
                Console.WriteLine("|2- Venda/Aluguel        |");
                Console.WriteLine("|3- Pesquisa             |");
                Console.WriteLine("|4- Relatorio de Vendas  |");
                Console.WriteLine("|5- Data de venda/locação|");
                Console.WriteLine("|6- Sair                 |");
                Console.WriteLine("--------------------------");
                Console.Write("Opção: ");
                opc = Console.ReadLine();

                switch (opc)
                {
                    //Cadastro 
                    case "1":
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("| Imobiliária Seu Lobato |");
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("|     Menu Cadastro      |");
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("|1- Proprietário         |");
                            Console.WriteLine("|2- Cliente              |");
                            Console.WriteLine("|3- Corretor             |");
                            Console.WriteLine("|4- Imóvel               |");
                            Console.WriteLine("|5- Sair                 |");
                            Console.WriteLine("--------------------------");
                            Console.Write("Opção: ");
                            opc_secundaria = Console.ReadLine();
                            switch (opc_secundaria)
                            {
                                //cadastro proprietario
                                case "1":
                                    CadastraProp();
                                    break;
                                //cadastro cliente
                                case "2":
                                    CadastraCliente();
                                    break;
                                //cadastro corretor
                                case "3":
                                    CadastraCorretor();
                                    break;
                                //cadastro imovel
                                case "4":
                                    CadastraImovel();
                                    break;
                                //para não cair no default
                                case "5":
                                    break;
                                //aviso
                                default:
                                    Console.WriteLine("Opção Inválida! Aperte qualquer tecla para continuar..");
                                    Console.ReadKey();
                                    break;
                            }

                        } while (opc != "5");
                        break;

                    //venda/aluguel
                    case "2":
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("| Imobiliária Seu Lobato |");
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("|  Menu Venda e Aluguel  |");
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("|1- Venda                |");
                            Console.WriteLine("|2- Aluguel              |");
                            Console.WriteLine("|3- Sair                 |");
                            Console.WriteLine("--------------------------");
                            Console.Write("Opção: ");
                            opc_secundaria = Console.ReadLine();
                            switch (opc_secundaria)
                            {
                                //venda
                                case "1":

                                    break;
                                //aluguel
                                case "2":

                                    break;

                                //não cair no default
                                case "3":
                                    break;

                                default:
                                    Console.WriteLine("Opção Inválida! Aperte qualquer tecla para continuar..");
                                    break;
                            }

                        } while (opc != "3");
                        break;

                    case "3":
                        do
                        {
                            Console.Clear();
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("| Imobiliária Seu Lobato |");
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("|    Menu de Pesquisa    |");
                            Console.WriteLine("--------------------------");
                            Console.WriteLine("|1- Clientes             |");
                            Console.WriteLine("|2- Proprietários        |");
                            Console.WriteLine("|3- Corretores           |");
                            Console.WriteLine("|4- Sair                 |");
                            Console.WriteLine("--------------------------");
                            Console.Write("Opção: ");
                            opc_secundaria = Console.ReadLine();
                            switch (opc_secundaria)
                            {
                                //pesquisar clientes
                                case "1":
                                    PesquisaCliente();
                                    break;
                                //pesquisar proprietarios
                                case "2":
                                    PesquisaProprietario();
                                    break;

                                //pesquisar corretores
                                case "3":
                                    PesquisaCorretor();
                                    break;
                                //não cair no default        
                                case "4":
                                    break;
                                //aviso
                                default:
                                    Console.WriteLine("Opção Inválida! Aperte qualquer tecla para continuar..");
                                    Console.ReadKey();
                                    break;
                            }

                        } while (opc != "4");
                        break;

                    case "4":
                        //chama relatorio
                        Console.Clear();
                        break;

                    case "5":
                        Console.Clear();
                        Console.WriteLine("--------------------------");
                        Console.WriteLine("| Imobiliária Seu Lobato |");
                        Console.WriteLine("--------------------------");
                        Console.WriteLine("|  Menu Venda e Aluguel  |");
                        Console.WriteLine("--------------------------");
                        Console.WriteLine("|1- Venda                |");
                        Console.WriteLine("|2- Aluguel              |");
                        Console.WriteLine("|3- Sair                 |");
                        Console.WriteLine("--------------------------");
                        Console.Write("Opção: ");
                        opc_secundaria = Console.ReadLine();
                        switch (opc_secundaria)
                        {
                            //venda
                            case "1":

                                break;
                            //aluguel
                            case "2":

                                break;

                            //não cair no default
                            case "3":
                                break;

                            default:
                                Console.WriteLine("Opção Inválida! Aperte qualquer tecla para continuar..");
                                Console.ReadKey();
                                break;
                        }
                        break;
                }
            } while (opc != "6") ;            
        }

        //PESQUISA NO SISTEMA CLIENTE
        public static void PesquisaCliente()
        {
            string clienteNome, linha, nomeP;

            Console.Clear();
            Console.WriteLine(" Imobiliária Seu Lobato: Pesquisa de cliente: ");

            FileStream arq = new FileStream("cliente.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            Console.WriteLine("\nDigite o nome informado no Cadastro do cliente:");
            clienteNome = Console.ReadLine().ToUpper();

            string[] resultado;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    nomeP = resultado[1];

                    if(nomeP == clienteNome)
                    {
                        Console.WriteLine("\nCódigo do cliente: " + resultado[0]);
                        Console.WriteLine("Nome do cliente: " + resultado[1]);
                        Console.WriteLine("Endereço do cliente: " + resultado[2]);
                        Console.WriteLine("Telefone do cliente: " + resultado[3]);
                        Console.WriteLine("Data de nascimento do cliente: {0}/{1}/{2}" + resultado[4], resultado[5], resultado[6]);
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Cliente não cadastrado!");
                        Console.ReadKey();
                    }
                }
            } while (linha != null);
            ler.Close();

        }

        //PESQUISA NO SISTEMA PROPRIETARIO
        public static void PesquisaProprietario()
        {
            string proprietarioNome, linha, nomeP;

            Console.Clear();
            Console.WriteLine(" Imobiliária Seu Lobato: Pesquisa de proprietário: ");

            FileStream arq = new FileStream("proprietario.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            Console.WriteLine("\nDigite o nome informado no Cadastro do proprietário:");
            proprietarioNome = Console.ReadLine().ToUpper();

            string[] resultado;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    nomeP = resultado[1];

                    if (nomeP == proprietarioNome)
                    {
                        Console.WriteLine("\nCódigo do proprietário: " + resultado[0]);
                        Console.WriteLine("Nome do proprietário: " + resultado[1]);
                        Console.WriteLine("Endereço do proprietário: " + resultado[2]);
                        Console.WriteLine("Telefone do proprietário: " + resultado[3]);
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Proprietário não cadastrado!");
                        Console.ReadKey();
                    }
                }
            } while (linha != null);
            ler.Close();
        }

        //PESQUISA NO SISTEMA CORRETOR
        public static void PesquisaCorretor()
        {
            string corretorNome, linha, nomeC;

            Console.Clear();
            Console.WriteLine(" Imobiliária Seu Lobato: Pesquisa de corretor: ");

            FileStream arq = new FileStream("corretor.txt", FileMode.OpenOrCreate);
            StreamReader ler = new StreamReader(arq);

            Console.WriteLine("\nDigite o nome informado no Cadastro do corretor:");
            corretorNome = Console.ReadLine().ToUpper();

            string[] resultado;

            do
            {
                linha = ler.ReadLine();
                if (linha != null)
                {
                    resultado = linha.Split('|');
                    nomeC = resultado[1];

                    if (nomeC == corretorNome)
                    {
                        Console.WriteLine("\nCódigo do corretor: " + resultado[0]);
                        Console.WriteLine("Nome do corretor: " + resultado[1]);
                        Console.WriteLine("Telefone do corretor: " + resultado[2]);
                        Console.WriteLine("Salário do corretor: " + resultado[3]);
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Corretor não cadastrado!");
                        Console.ReadKey();
                    }
                }
            } while (linha != null);
            ler.Close();
        }

        static void Main(string[] args)
        {
            Menu();
        }
    }
}
